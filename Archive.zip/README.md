npm install

npm run server
